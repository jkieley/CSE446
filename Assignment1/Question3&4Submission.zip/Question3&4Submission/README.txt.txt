Created using Visual Studio 2013
Questions  3  and  4  Submission.

Visual Studio Solution File can be found in:
\Projects\ConsoleApplication1\WcfServiceConsole.v12

Selfhosing Service can be found in:
\Projects\ConsoleApplication1\ConsoleApplication1

Number Guessing Console Game can be found in:
\Projects\ConsoleApplication1\ConsoleApplication2

Test Results can be found in:
/CSE446Assignment1Question3and4TestingResults.docx