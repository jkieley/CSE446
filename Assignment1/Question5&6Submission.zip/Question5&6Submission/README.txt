Created using Visual Studio 2013
Questions  1  and  2  Submission.
While Both my WCF Service and ASP .Net Web Forms Site are within the same Visual Studio Solution.
Visual Studio stores them in different folders. To maintain the folder structure I have included both folder structures.

Visual Studio Solution File can be found in:
\Projects\WCFService1\WCFService1.v12

ASP .Net Web Forms Site can be found in:
\Projects\WCFService1\WebApplication2

WCF Service can be found in 
\WebSites\WCFService1

Test Results can be seen in:
\CSE446Assignment1Question5and6TestingResults.docx