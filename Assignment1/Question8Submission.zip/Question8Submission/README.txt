Created using Visual Studio 2013
Questions  1  and  2  Submission.
To maintain the folder structures.

Visual Studio Solution File can be found in:
\Projects\WCFService1\WCFService1.v12

Windows form application can be found in:
\Projects\WCFService1\WindowsFormsApplication1

WCF Service can be found in 
\WebSites\WCFService1

NOTE: 
typing this command in the package manager console in visual studios was required to enable async operations.
install-package Microsoft.Bcl.Async �pre

see this artical: http://blogs.msdn.com/b/bclteam/archive/2012/10/19/using-async-await-without-net-framework-4-5.aspx