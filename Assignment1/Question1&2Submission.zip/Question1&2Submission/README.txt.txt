Created using Visual Studio 2013
Questions  1  and  2  Submission.
While Both my WCF Service and Windows Form Application are within the same Visual Studio Solution.
Visual Studio stores them in different folders. To maintain the folder structure I have included both folder structures.

Visual Studio Solution File can be found in:
\Projects\WCFService1\WCFService1.v12

Windows form application can be found in:
\Projects\WCFService1\WindowsFormsApplication1

WCF Service can be found in 
\WebSites\WCFService1


