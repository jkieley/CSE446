Created using Visual Studio 2013
Questions  1  and  2  Submission.
To maintain the folder structure I have included both folder structures.

Visual Studio Solution File can be found in:
\Projects\WCFService1\WCFService1.v12

WCF Service can be found in 
\WebSites\WCFService1

Test Results can be found in:
\CSE446Assignment1Question7TestResults.docx