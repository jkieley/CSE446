James Kieley
Assignment 2
CSE 446

Execute Application Instructions:
- Run Workflow Foundation SOAP Service First (Non Debug Mode). Note Administrator privileges required, static port set to 1000
- Then Run Application

Submission Details:

1. Workflow Foundation SOAP Service
\Projects\WorkflowConsoleApplication1\WorkflowService1

2. Workflow Application using at least 2 services
\Projects\WorkflowConsoleApplication1\WorkflowConsoleApplication1

3. Sensible Code Activity
\Projects\WorkflowConsoleApplication1\WorkflowConsoleApplication1\TestGuessInput.cs

4. User Manual
\Assignment 2 User Manual.pdf