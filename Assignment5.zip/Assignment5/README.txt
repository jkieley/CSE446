Solution File:
.\Projects\Assignment5WcfService\Assignment5WcfService.sln

WCFService
.\Projects\Assignment5WcfService\Assignment5WcfService

Asp .net Web Application:
.\Projects\Assignment5WcfService\Assignment5WebApplication1