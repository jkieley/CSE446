1.1 BPEL XML
./SOA/BPEL/BPELProcess1.bpel

1.2 WSDL file for your BPEL process
./SOA/WSDLs/BPELProcess1.wsdl